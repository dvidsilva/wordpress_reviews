cd ..
rm dodreviews/pack.zip
zip -r dodreviews/pack.zip dodreviews -x "dodreviews/_source/*" "dodreviews/.git/*" "dodreviews/.DS_Store"